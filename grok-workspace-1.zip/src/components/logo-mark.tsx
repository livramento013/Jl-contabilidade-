export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 52" className={className} fill="none" aria-hidden="true">
      <path
        fill="currentColor"
        d="M4 38.5V23.2c0-1.1.9-2 2-2h6.2c1.1 0 2 .9 2 2v15.3H4Zm12.4 0V15.4c0-1.1.9-2 2-2h7.4c1.1 0 2 .9 2 2v23.1h-11.4Zm13.6 0V8.6c0-1.1.9-2 2-2H40c1.1 0 2 .9 2 2v29.9H30Zm14.2 0V18.2c0-1.1.9-2 2-2H54c1.1 0 2 .9 2 2v20.3H44.2Z"
      />
      <path
        d="M3 41.2c11-7.2 18.6-7.6 28-2.2 7.4 4.2 14.4 5 30.2-.4"
        stroke="currentColor"
        strokeWidth="2.1"
        strokeLinecap="round"
      />
    </svg>
  );
}
