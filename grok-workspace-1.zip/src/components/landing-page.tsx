import { useState, type FormEvent } from "react";
import {
  ArrowUpRight,
  Banknote,
  Building2,
  Calculator,
  Files,
  LifeBuoy,
  Mail,
  Menu,
  Monitor,
  X,
  type LucideIcon,
} from "lucide-react";
import { LogoMark } from "@/components/logo-mark";

const WHATSAPP_NUMBER = "5511952839374";
const WHATSAPP_DISPLAY = "(11) 95283-9374";
const EMAIL = "jlservicosterceirizados@gmail.com";
const HELLO =
  "Olá, Jeniffer! Vim pelo site da JL Serviços Terceirizados e gostaria de conversar.";

type Service = {
  id: string;
  index: string;
  title: string;
  text: string;
  icon: LucideIcon;
};

const services: Service[] = [
  {
    id: "documentacao",
    index: "01",
    title: "Documentação para empreiteiras",
    text: "Contratos, controles e a papelada da obra reunidos para achar o que precisa, quando precisa.",
    icon: Files,
  },
  {
    id: "plataformas",
    index: "02",
    title: "Controle de plataformas digitais",
    text: "Organização do que entra e sai nas plataformas que o negócio já usa, com a rotina acompanhada.",
    icon: Monitor,
  },
  {
    id: "folha",
    index: "03",
    title: "Folha de pagamento",
    text: "Apoio na folha: conferência, lançamentos e o calendário sob controle.",
    icon: Banknote,
  },
  {
    id: "ir",
    index: "04",
    title: "Imposto de Renda",
    text: "Informações organizadas e apoio na declaração, com clareza do que ainda falta.",
    icon: Calculator,
  },
  {
    id: "empresa",
    index: "05",
    title: "Abertura e fechamento de empresa",
    text: "O caminho administrativo para abrir ou encerrar um CNPJ, com a documentação no lugar.",
    icon: Building2,
  },
  {
    id: "mei",
    index: "06",
    title: "Suporte MEI e administrativo",
    text: "Rotina do MEI e do escritório: prazos, documentos e o que precisa sair da sua mesa.",
    icon: LifeBuoy,
  },
];

function whatsappHref(text: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
}

function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" fill="currentColor">
      <path d="M12.04 2C6.58 2 2.15 6.4 2.15 11.83c0 1.74.46 3.44 1.34 4.94L2 22l5.39-1.4a10 10 0 0 0 4.65 1.18h.01c5.46 0 9.89-4.4 9.89-9.83C21.94 6.4 17.5 2 12.04 2zm5.78 13.95c-.24.68-1.4 1.3-1.94 1.38-.5.07-1.12.1-1.81-.11-.42-.13-.95-.3-1.64-.59-2.88-1.24-4.76-4.14-4.9-4.33-.14-.19-1.16-1.54-1.16-2.94s.73-2.08 1-2.37c.24-.27.64-.39.86-.39h.62c.2 0 .46-.07.72.55.27.64.9 2.2.98 2.36.08.16.13.35.03.56-.1.2-.15.33-.3.51-.14.17-.3.38-.43.51-.14.14-.29.29-.12.56.16.27.73 1.2 1.57 1.95 1.08.96 1.99 1.26 2.27 1.4.28.14.44.12.6-.07.17-.19.7-.81.89-1.09.19-.28.38-.23.64-.14.26.09 1.66.78 1.94.92.29.14.48.21.55.33.07.12.07.68-.17 1.36z" />
    </svg>
  );
}

function Wordmark({ compact = false }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-3">
      <LogoMark className={compact ? "h-9 w-9 text-brand" : "h-14 w-14 text-brand"} />
      <span className="block leading-none">
        <span
          className={`block font-display tracking-tight text-ink ${compact ? "text-lg" : "text-3xl"}`}
        >
          JL serviços
        </span>
        <span
          className={`block font-display italic text-brand ${compact ? "text-sm" : "mt-1 text-2xl"}`}
        >
          terceirizados
        </span>
      </span>
    </span>
  );
}

export function LandingPage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [serviceId, setServiceId] = useState(services[0].id);
  const [note, setNote] = useState("");

  const helloHref = whatsappHref(HELLO);

  function chooseService(id: string) {
    setServiceId(id);
    setMenuOpen(false);
    const target = document.getElementById("contato");
    if (!target) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    target.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
  }

  function openChat(event: FormEvent) {
    event.preventDefault();
    const service = services.find((item) => item.id === serviceId);
    const lines = [
      "Olá, Jeniffer! Vim pelo site da JL Serviços Terceirizados.",
      `Gostaria de falar sobre: ${service?.title ?? "os serviços"}.`,
    ];
    const extra = note.trim();
    if (extra) lines.push(extra);
    window.open(whatsappHref(lines.join("\n")), "_blank", "noopener,noreferrer");
  }

  return (
    <div className="min-h-screen bg-paper text-ink">
      <header className="sticky top-0 z-40 border-b border-line bg-paper/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-3">
          <a href="#topo" className="rounded-md focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-brand">
            <Wordmark compact />
            <span className="sr-only">JL Serviços Terceirizados</span>
          </a>
          <nav className="hidden items-center gap-8 md:flex" aria-label="Seções">
            <a href="#servicos" className="text-sm font-medium text-muted transition-colors hover:text-ink">
              Serviços
            </a>
            <a href="#destaque" className="text-sm font-medium text-muted transition-colors hover:text-ink">
              Diferencial
            </a>
            <a href="#contato" className="text-sm font-medium text-muted transition-colors hover:text-ink">
              Contato
            </a>
          </nav>
          <div className="flex items-center gap-2">
            <a
              href={helloHref}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden h-11 items-center gap-2 rounded-full bg-brand px-5 text-sm font-medium text-paper transition-transform duration-150 ease-out hover:bg-brand-deep active:scale-[0.96] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand md:inline-flex"
            >
              <WhatsAppIcon className="h-4 w-4" />
              Falar com a Jeniffer
            </a>
            <button
              type="button"
              className="grid h-11 w-11 place-items-center rounded-full border border-line text-ink md:hidden"
              aria-expanded={menuOpen}
              aria-controls="menu-mobile"
              onClick={() => setMenuOpen((open) => !open)}
            >
              {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              <span className="sr-only">{menuOpen ? "Fechar menu" : "Abrir menu"}</span>
            </button>
          </div>
        </div>
        <div id="menu-mobile" className={`menu-panel md:hidden ${menuOpen ? "open" : ""}`}>
          <div className="overflow-hidden">
            <nav className="flex flex-col gap-1 px-5 pb-4" aria-label="Seções">
              {[
                ["#servicos", "Serviços"],
                ["#destaque", "Diferencial"],
                ["#contato", "Contato"],
              ].map(([href, label]) => (
                <a
                  key={href}
                  href={href}
                  onClick={() => setMenuOpen(false)}
                  className="flex h-12 items-center rounded-xl px-3 text-base font-medium text-ink hover:bg-mist"
                >
                  {label}
                </a>
              ))}
            </nav>
          </div>
        </div>
      </header>

      <main id="topo">
        <section className="mx-auto grid max-w-6xl items-center gap-10 px-5 pb-16 pt-10 lg:grid-cols-2 lg:gap-16 lg:pb-24 lg:pt-16">
          <div>
            <div className="rise">
              <Wordmark />
            </div>
            <p className="rise rise-2 mt-8 text-xs font-medium uppercase tracking-widest text-brand">
              Contabilidade e suporte administrativo
            </p>
            <h1 className="rise rise-2 mt-4 font-display text-4xl leading-tight text-ink sm:text-6xl lg:text-7xl">
              Seu negócio
              <span className="mt-1 block italic text-brand">em boas mãos.</span>
            </h1>
            <p className="rise rise-3 mt-6 max-w-xl text-lg leading-relaxed text-muted">
              A JL organiza documentação, folha, imposto de renda e a rotina do escritório —
              inclusive do MEI — para o seu negócio seguir com clareza.
            </p>
            <div className="rise rise-4 mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
              <a
                href={helloHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-brand px-6 text-base font-medium text-paper transition-transform duration-150 ease-out hover:bg-brand-deep active:scale-[0.96] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand"
              >
                <WhatsAppIcon className="h-5 w-5" />
                Falar com a Jeniffer no WhatsApp
              </a>
              <a
                href={`mailto:${EMAIL}`}
                className="inline-flex h-12 items-center justify-center px-2 text-sm font-medium text-muted underline decoration-line underline-offset-4 hover:text-ink"
              >
                ou enviar um e-mail
              </a>
            </div>
          </div>
          <figure className="rise rise-3">
            <img
              src="/images/hero-office.jpg"
              alt="Mesa clara com notebook, planta e porta-canetas em um escritório iluminado."
              width={1792}
              height={1008}
              fetchPriority="high"
              className="aspect-portrait w-full rounded-3xl object-cover shadow-float ring-1 ring-line"
            />
          </figure>
        </section>

        <section id="servicos" className="scroll-mt-24 bg-mist">
          <div className="mx-auto grid max-w-6xl items-end gap-8 px-5 pb-8 pt-16 lg:grid-cols-12 lg:pt-20">
            <div className="lg:col-span-6">
              <p className="text-xs font-medium uppercase tracking-widest text-brand">Serviços</p>
              <h2 className="mt-3 font-display text-4xl leading-tight text-ink sm:text-5xl">
                O que cuidamos por você
              </h2>
            </div>
            <p className="max-w-md text-base leading-relaxed text-muted lg:col-span-6 lg:justify-self-end">
              Seis frentes da rotina administrativa. Escolha um assunto e a conversa já abre
              com a Jeniffer, no WhatsApp.
            </p>
          </div>
          <div className="mx-auto grid max-w-6xl gap-4 px-5 pb-6 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((service) => {
              const Icon = service.icon;
              return (
                <article
                  key={service.id}
                  className="group flex flex-col rounded-3xl border border-line bg-paper p-6 shadow-float transition-transform duration-200 ease-out hover:-translate-y-1"
                >
                  <div className="flex items-start justify-between gap-4">
                    <span className="font-display text-2xl text-brand/50">{service.index}</span>
                    <span className="grid h-12 w-12 place-items-center rounded-full bg-lilac text-brand">
                      <Icon className="h-5 w-5" strokeWidth={1.75} />
                    </span>
                  </div>
                  <h3 className="mt-8 font-display text-2xl leading-snug text-ink">{service.title}</h3>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-muted">{service.text}</p>
                  <button
                    type="button"
                    onClick={() => chooseService(service.id)}
                    className="mt-6 inline-flex h-11 items-center gap-1 self-start text-sm font-medium text-brand"
                  >
                    Falar sobre isso
                    <ArrowUpRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </button>
                </article>
              );
            })}
          </div>
          <div className="mx-auto grid max-w-6xl items-center gap-6 px-5 pb-16 pt-4 lg:grid-cols-12 lg:pb-24">
            <img
              src="/images/shelf.jpg"
              alt="Estante branca com pastas organizadas e uma planta ao lado da janela."
              width={1600}
              height={1200}
              loading="lazy"
              className="aspect-video w-full rounded-3xl object-cover ring-1 ring-line lg:col-span-7"
            />
            <p className="font-display text-2xl leading-snug text-ink lg:col-span-5">
              Feito para empreiteiras, MEI e quem precisa de um escritório que responde no tempo do negócio.
            </p>
          </div>
        </section>

        <section id="destaque" className="scroll-mt-24">
          <svg
            viewBox="0 0 1440 100"
            preserveAspectRatio="none"
            className="block h-16 w-full bg-mist text-brand md:h-24"
            aria-hidden="true"
          >
            <path
              fill="currentColor"
              d="M0 100V46C280 96 560 4 900 28c250 18 390 52 540 8v64H0Z"
            />
          </svg>
          <div className="bg-brand text-paper">
            <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-12 lg:grid-cols-12 lg:py-16">
              <div className="lg:col-span-7">
                <p className="text-xs font-medium uppercase tracking-widest text-paper/75">Em destaque</p>
                <p className="mt-4 font-display text-4xl italic leading-tight sm:text-5xl lg:text-6xl">
                  Organização, agilidade e resultados!
                </p>
                <p className="mt-6 max-w-lg text-base leading-relaxed text-paper/80">
                  A rotina do escritório no lugar, com resposta rápida e entrega organizada.
                </p>
              </div>
              <img
                src="/images/notebook.jpg"
                alt="Caderno aberto e caneta sobre uma mesa branca."
                width={1728}
                height={1152}
                loading="lazy"
                className="aspect-portrait w-full rounded-3xl object-cover ring-1 ring-paper/30 lg:col-span-5"
              />
            </div>
          </div>
          <svg
            viewBox="0 0 1440 100"
            preserveAspectRatio="none"
            className="block h-16 w-full bg-paper text-brand md:h-24"
            aria-hidden="true"
          >
            <path
              fill="currentColor"
              d="M0 0v62C260 18 620 98 980 48c210-32 340-8 460 24V0H0Z"
            />
          </svg>
        </section>

        <section id="contato" className="scroll-mt-24">
          <div className="mx-auto grid max-w-6xl gap-12 px-5 pb-16 pt-6 lg:grid-cols-12 lg:pb-24 lg:pt-4">
            <div className="lg:col-span-6">
              <p className="text-xs font-medium uppercase tracking-widest text-brand">Contato</p>
              <h2 className="mt-3 font-display text-4xl leading-tight text-ink sm:text-5xl">
                Fale com a Jeniffer.
              </h2>
              <p className="mt-4 max-w-md text-base leading-relaxed text-muted">
                Escolha o assunto e abra a conversa no WhatsApp. Se preferir, o e-mail também chega direto.
              </p>
              <img
                src="/images/desk.jpg"
                alt="Caderno preto e uma pasta roxa na quina de uma mesa clara."
                width={1792}
                height={1008}
                loading="lazy"
                className="mt-8 aspect-video w-full rounded-3xl object-cover ring-1 ring-line"
              />
              <div className="mt-6 flex flex-col gap-3">
                <a
                  href={helloHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex min-h-16 items-center gap-4 rounded-2xl border border-line bg-paper px-4 py-3 transition-colors hover:border-brand"
                >
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-brand text-paper">
                    <WhatsAppIcon className="h-5 w-5" />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-sm text-muted">WhatsApp</span>
                    <span className="block font-display text-2xl text-ink">{WHATSAPP_DISPLAY}</span>
                  </span>
                </a>
                <a
                  href={`mailto:${EMAIL}`}
                  className="flex min-h-16 items-center gap-4 rounded-2xl border border-line bg-paper px-4 py-3 transition-colors hover:border-brand"
                >
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-lilac text-brand">
                    <Mail className="h-5 w-5" />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-sm text-muted">E-mail</span>
                    <span className="block break-all text-base font-medium text-ink sm:text-lg">{EMAIL}</span>
                  </span>
                </a>
              </div>
            </div>

            <form
              onSubmit={openChat}
              className="rounded-3xl bg-mist p-6 ring-1 ring-line lg:col-span-6 lg:p-8"
            >
              <h3 className="font-display text-3xl text-ink">Começar uma conversa</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">
                O recado abre no WhatsApp da Jeniffer, pronto para enviar.
              </p>
              <fieldset className="mt-6">
                <legend className="text-sm font-medium text-ink">Sobre o que você quer falar?</legend>
                <div className="mt-3 flex flex-wrap gap-2">
                  {services.map((service) => {
                    const selected = service.id === serviceId;
                    return (
                      <button
                        key={service.id}
                        type="button"
                        aria-pressed={selected}
                        onClick={() => setServiceId(service.id)}
                        className={`min-h-11 rounded-full border px-4 py-2 text-left text-sm transition-colors ${
                          selected
                            ? "border-brand bg-brand text-paper"
                            : "border-line bg-paper text-ink hover:border-brand"
                        }`}
                      >
                        {service.title}
                      </button>
                    );
                  })}
                </div>
              </fieldset>
              <label htmlFor="recado" className="mt-6 block text-sm font-medium text-ink">
                Recado <span className="font-normal text-muted">(opcional)</span>
              </label>
              <textarea
                id="recado"
                name="recado"
                rows={4}
                maxLength={400}
                value={note}
                onChange={(event) => setNote(event.target.value)}
                placeholder="Conte em uma frase o que você precisa."
                className="mt-2 w-full resize-none rounded-2xl border border-line bg-paper px-4 py-3 text-base text-ink outline-none placeholder:text-muted focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand"
              />
              <button
                type="submit"
                className="mt-5 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-brand px-6 text-base font-medium text-paper transition-transform duration-150 ease-out hover:bg-brand-deep active:scale-[0.96] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand"
              >
                <WhatsAppIcon className="h-5 w-5" />
                Abrir conversa no WhatsApp
              </button>
            </form>
          </div>
        </section>
      </main>

      <footer className="bg-brand-deep px-5 pb-28 pt-10 text-paper md:pb-10">
        <div className="mx-auto flex max-w-6xl flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <span className="flex items-center gap-3">
              <LogoMark className="h-9 w-9 text-paper" />
              <span>
                <span className="block font-display text-lg leading-none">JL serviços</span>
                <span className="block font-display text-sm italic text-paper/80">terceirizados</span>
              </span>
            </span>
            <p className="mt-4 text-sm text-paper/75">Seu negócio em boas mãos.</p>
          </div>
          <div className="text-sm text-paper/75">
            <a href={helloHref} target="_blank" rel="noopener noreferrer" className="block hover:text-paper">
              {WHATSAPP_DISPLAY}
            </a>
            <a href={`mailto:${EMAIL}`} className="mt-1 block break-all hover:text-paper">
              {EMAIL}
            </a>
            <p className="mt-4">© {new Date().getFullYear()} JL Serviços Terceirizados</p>
          </div>
        </div>
      </footer>

      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-paper/95 p-3 backdrop-blur-md md:hidden">
        <a
          href={helloHref}
          target="_blank"
          rel="noopener noreferrer"
          className="flex h-12 items-center justify-center gap-2 rounded-full bg-brand text-sm font-medium text-paper"
        >
          <WhatsAppIcon className="h-4 w-4" />
          Falar com a Jeniffer no WhatsApp
        </a>
      </div>
    </div>
  );
}
