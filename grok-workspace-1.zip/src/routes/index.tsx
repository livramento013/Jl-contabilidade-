import { createFileRoute } from "@tanstack/react-router";
import { LandingPage } from "@/components/landing-page";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "JL Serviços Terceirizados — Seu negócio em boas mãos" },
      {
        name: "description",
        content:
          "Contabilidade e suporte administrativo: documentação para empreiteiras, folha de pagamento, imposto de renda, abertura de empresa e suporte MEI. Fale com a Jeniffer.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  return <LandingPage />;
}
