//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CugTHb4y.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BIf_wSFW.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BIf_wSFW.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BTYucPd-.js"]
	}
} });
//#endregion
export { tsrStartManifest };
