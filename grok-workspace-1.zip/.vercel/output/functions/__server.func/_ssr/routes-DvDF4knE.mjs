import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Mail, c as Calculator, d as ArrowUpRight, i as Menu, l as Building2, o as LifeBuoy, r as Monitor, s as Files, t as X, u as Banknote } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DvDF4knE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LogoMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 52",
		className,
		fill: "none",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: "currentColor",
			d: "M4 38.5V23.2c0-1.1.9-2 2-2h6.2c1.1 0 2 .9 2 2v15.3H4Zm12.4 0V15.4c0-1.1.9-2 2-2h7.4c1.1 0 2 .9 2 2v23.1h-11.4Zm13.6 0V8.6c0-1.1.9-2 2-2H40c1.1 0 2 .9 2 2v29.9H30Zm14.2 0V18.2c0-1.1.9-2 2-2H54c1.1 0 2 .9 2 2v20.3H44.2Z"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M3 41.2c11-7.2 18.6-7.6 28-2.2 7.4 4.2 14.4 5 30.2-.4",
			stroke: "currentColor",
			strokeWidth: "2.1",
			strokeLinecap: "round"
		})]
	});
}
var WHATSAPP_NUMBER = "5511952839374";
var WHATSAPP_DISPLAY = "(11) 95283-9374";
var EMAIL = "jlservicosterceirizados@gmail.com";
var HELLO = "Olá, Jeniffer! Vim pelo site da JL Serviços Terceirizados e gostaria de conversar.";
var services = [
	{
		id: "documentacao",
		index: "01",
		title: "Documentação para empreiteiras",
		text: "Contratos, controles e a papelada da obra reunidos para achar o que precisa, quando precisa.",
		icon: Files
	},
	{
		id: "plataformas",
		index: "02",
		title: "Controle de plataformas digitais",
		text: "Organização do que entra e sai nas plataformas que o negócio já usa, com a rotina acompanhada.",
		icon: Monitor
	},
	{
		id: "folha",
		index: "03",
		title: "Folha de pagamento",
		text: "Apoio na folha: conferência, lançamentos e o calendário sob controle.",
		icon: Banknote
	},
	{
		id: "ir",
		index: "04",
		title: "Imposto de Renda",
		text: "Informações organizadas e apoio na declaração, com clareza do que ainda falta.",
		icon: Calculator
	},
	{
		id: "empresa",
		index: "05",
		title: "Abertura e fechamento de empresa",
		text: "O caminho administrativo para abrir ou encerrar um CNPJ, com a documentação no lugar.",
		icon: Building2
	},
	{
		id: "mei",
		index: "06",
		title: "Suporte MEI e administrativo",
		text: "Rotina do MEI e do escritório: prazos, documentos e o que precisa sair da sua mesa.",
		icon: LifeBuoy
	}
];
function whatsappHref(text) {
	return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
}
function WhatsAppIcon({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className,
		"aria-hidden": "true",
		fill: "currentColor",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12.04 2C6.58 2 2.15 6.4 2.15 11.83c0 1.74.46 3.44 1.34 4.94L2 22l5.39-1.4a10 10 0 0 0 4.65 1.18h.01c5.46 0 9.89-4.4 9.89-9.83C21.94 6.4 17.5 2 12.04 2zm5.78 13.95c-.24.68-1.4 1.3-1.94 1.38-.5.07-1.12.1-1.81-.11-.42-.13-.95-.3-1.64-.59-2.88-1.24-4.76-4.14-4.9-4.33-.14-.19-1.16-1.54-1.16-2.94s.73-2.08 1-2.37c.24-.27.64-.39.86-.39h.62c.2 0 .46-.07.72.55.27.64.9 2.2.98 2.36.08.16.13.35.03.56-.1.2-.15.33-.3.51-.14.17-.3.38-.43.51-.14.14-.29.29-.12.56.16.27.73 1.2 1.57 1.95 1.08.96 1.99 1.26 2.27 1.4.28.14.44.12.6-.07.17-.19.7-.81.89-1.09.19-.28.38-.23.64-.14.26.09 1.66.78 1.94.92.29.14.48.21.55.33.07.12.07.68-.17 1.36z" })
	});
}
function Wordmark({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: compact ? "h-9 w-9 text-brand" : "h-14 w-14 text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "block leading-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `block font-display tracking-tight text-ink ${compact ? "text-lg" : "text-3xl"}`,
				children: "JL serviços"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `block font-display italic text-brand ${compact ? "text-sm" : "mt-1 text-2xl"}`,
				children: "terceirizados"
			})]
		})]
	});
}
function LandingPage() {
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [serviceId, setServiceId] = (0, import_react.useState)(services[0].id);
	const [note, setNote] = (0, import_react.useState)("");
	const helloHref = whatsappHref(HELLO);
	function chooseService(id) {
		setServiceId(id);
		setMenuOpen(false);
		const target = document.getElementById("contato");
		if (!target) return;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		target.scrollIntoView({
			behavior: reduce ? "auto" : "smooth",
			block: "start"
		});
	}
	function openChat(event) {
		event.preventDefault();
		const lines = ["Olá, Jeniffer! Vim pelo site da JL Serviços Terceirizados.", `Gostaria de falar sobre: ${services.find((item) => item.id === serviceId)?.title ?? "os serviços"}.`];
		const extra = note.trim();
		if (extra) lines.push(extra);
		window.open(whatsappHref(lines.join("\n")), "_blank", "noopener,noreferrer");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-40 border-b border-line bg-paper/90 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#topo",
							className: "rounded-md focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-brand",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, { compact: true }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "JL Serviços Terceirizados"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "hidden items-center gap-8 md:flex",
							"aria-label": "Seções",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#servicos",
									className: "text-sm font-medium text-muted transition-colors hover:text-ink",
									children: "Serviços"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#destaque",
									className: "text-sm font-medium text-muted transition-colors hover:text-ink",
									children: "Diferencial"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#contato",
									className: "text-sm font-medium text-muted transition-colors hover:text-ink",
									children: "Contato"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: helloHref,
								target: "_blank",
								rel: "noopener noreferrer",
								className: "hidden h-11 items-center gap-2 rounded-full bg-brand px-5 text-sm font-medium text-paper transition-transform duration-150 ease-out hover:bg-brand-deep active:scale-[0.96] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand md:inline-flex",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, { className: "h-4 w-4" }), "Falar com a Jeniffer"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "grid h-11 w-11 place-items-center rounded-full border border-line text-ink md:hidden",
								"aria-expanded": menuOpen,
								"aria-controls": "menu-mobile",
								onClick: () => setMenuOpen((open) => !open),
								children: [menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: menuOpen ? "Fechar menu" : "Abrir menu"
								})]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: "menu-mobile",
					className: `menu-panel md:hidden ${menuOpen ? "open" : ""}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "flex flex-col gap-1 px-5 pb-4",
							"aria-label": "Seções",
							children: [
								["#servicos", "Serviços"],
								["#destaque", "Diferencial"],
								["#contato", "Contato"]
							].map(([href, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href,
								onClick: () => setMenuOpen(false),
								className: "flex h-12 items-center rounded-xl px-3 text-base font-medium text-ink hover:bg-mist",
								children: label
							}, href))
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "topo",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mx-auto grid max-w-6xl items-center gap-10 px-5 pb-16 pt-10 lg:grid-cols-2 lg:gap-16 lg:pb-24 lg:pt-16",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rise",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rise rise-2 mt-8 text-xs font-medium uppercase tracking-widest text-brand",
								children: "Contabilidade e suporte administrativo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "rise rise-2 mt-4 font-display text-4xl leading-tight text-ink sm:text-6xl lg:text-7xl",
								children: ["Seu negócio", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block italic text-brand",
									children: "em boas mãos."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rise rise-3 mt-6 max-w-xl text-lg leading-relaxed text-muted",
								children: "A JL organiza documentação, folha, imposto de renda e a rotina do escritório — inclusive do MEI — para o seu negócio seguir com clareza."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rise rise-4 mt-8 flex flex-col gap-3 sm:flex-row sm:items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: helloHref,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "inline-flex h-12 items-center justify-center gap-2 rounded-full bg-brand px-6 text-base font-medium text-paper transition-transform duration-150 ease-out hover:bg-brand-deep active:scale-[0.96] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, { className: "h-5 w-5" }), "Falar com a Jeniffer no WhatsApp"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `mailto:${EMAIL}`,
									className: "inline-flex h-12 items-center justify-center px-2 text-sm font-medium text-muted underline decoration-line underline-offset-4 hover:text-ink",
									children: "ou enviar um e-mail"
								})]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
							className: "rise rise-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/images/hero-office.jpg",
								alt: "Mesa clara com notebook, planta e porta-canetas em um escritório iluminado.",
								width: 1792,
								height: 1008,
								fetchPriority: "high",
								className: "aspect-portrait w-full rounded-3xl object-cover shadow-float ring-1 ring-line"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "servicos",
						className: "scroll-mt-24 bg-mist",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto grid max-w-6xl items-end gap-8 px-5 pb-8 pt-16 lg:grid-cols-12 lg:pt-20",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "lg:col-span-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium uppercase tracking-widest text-brand",
										children: "Serviços"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-3 font-display text-4xl leading-tight text-ink sm:text-5xl",
										children: "O que cuidamos por você"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "max-w-md text-base leading-relaxed text-muted lg:col-span-6 lg:justify-self-end",
									children: "Seis frentes da rotina administrativa. Escolha um assunto e a conversa já abre com a Jeniffer, no WhatsApp."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mx-auto grid max-w-6xl gap-4 px-5 pb-6 sm:grid-cols-2 lg:grid-cols-3",
								children: services.map((service) => {
									const Icon = service.icon;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "group flex flex-col rounded-3xl border border-line bg-paper p-6 shadow-float transition-transform duration-200 ease-out hover:-translate-y-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-start justify-between gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-display text-2xl text-brand/50",
													children: service.index
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "grid h-12 w-12 place-items-center rounded-full bg-lilac text-brand",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
														className: "h-5 w-5",
														strokeWidth: 1.75
													})
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-8 font-display text-2xl leading-snug text-ink",
												children: service.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-3 flex-1 text-sm leading-relaxed text-muted",
												children: service.text
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => chooseService(service.id),
												className: "mt-6 inline-flex h-11 items-center gap-1 self-start text-sm font-medium text-brand",
												children: ["Falar sobre isso", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-4 w-4 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" })]
											})
										]
									}, service.id);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto grid max-w-6xl items-center gap-6 px-5 pb-16 pt-4 lg:grid-cols-12 lg:pb-24",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/images/shelf.jpg",
									alt: "Estante branca com pastas organizadas e uma planta ao lado da janela.",
									width: 1600,
									height: 1200,
									loading: "lazy",
									className: "aspect-video w-full rounded-3xl object-cover ring-1 ring-line lg:col-span-7"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-2xl leading-snug text-ink lg:col-span-5",
									children: "Feito para empreiteiras, MEI e quem precisa de um escritório que responde no tempo do negócio."
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "destaque",
						className: "scroll-mt-24",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								viewBox: "0 0 1440 100",
								preserveAspectRatio: "none",
								className: "block h-16 w-full bg-mist text-brand md:h-24",
								"aria-hidden": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									fill: "currentColor",
									d: "M0 100V46C280 96 560 4 900 28c250 18 390 52 540 8v64H0Z"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-brand text-paper",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mx-auto grid max-w-6xl items-center gap-10 px-5 py-12 lg:grid-cols-12 lg:py-16",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "lg:col-span-7",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-medium uppercase tracking-widest text-paper/75",
												children: "Em destaque"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-4 font-display text-4xl italic leading-tight sm:text-5xl lg:text-6xl",
												children: "Organização, agilidade e resultados!"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-6 max-w-lg text-base leading-relaxed text-paper/80",
												children: "A rotina do escritório no lugar, com resposta rápida e entrega organizada."
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/images/notebook.jpg",
										alt: "Caderno aberto e caneta sobre uma mesa branca.",
										width: 1728,
										height: 1152,
										loading: "lazy",
										className: "aspect-portrait w-full rounded-3xl object-cover ring-1 ring-paper/30 lg:col-span-5"
									})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								viewBox: "0 0 1440 100",
								preserveAspectRatio: "none",
								className: "block h-16 w-full bg-paper text-brand md:h-24",
								"aria-hidden": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									fill: "currentColor",
									d: "M0 0v62C260 18 620 98 980 48c210-32 340-8 460 24V0H0Z"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "contato",
						className: "scroll-mt-24",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl gap-12 px-5 pb-16 pt-6 lg:grid-cols-12 lg:pb-24 lg:pt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "lg:col-span-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium uppercase tracking-widest text-brand",
										children: "Contato"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-3 font-display text-4xl leading-tight text-ink sm:text-5xl",
										children: "Fale com a Jeniffer."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 max-w-md text-base leading-relaxed text-muted",
										children: "Escolha o assunto e abra a conversa no WhatsApp. Se preferir, o e-mail também chega direto."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/images/desk.jpg",
										alt: "Caderno preto e uma pasta roxa na quina de uma mesa clara.",
										width: 1792,
										height: 1008,
										loading: "lazy",
										className: "mt-8 aspect-video w-full rounded-3xl object-cover ring-1 ring-line"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 flex flex-col gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: helloHref,
											target: "_blank",
											rel: "noopener noreferrer",
											className: "flex min-h-16 items-center gap-4 rounded-2xl border border-line bg-paper px-4 py-3 transition-colors hover:border-brand",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "grid h-12 w-12 shrink-0 place-items-center rounded-full bg-brand text-paper",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, { className: "h-5 w-5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block text-sm text-muted",
													children: "WhatsApp"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block font-display text-2xl text-ink",
													children: WHATSAPP_DISPLAY
												})]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: `mailto:${EMAIL}`,
											className: "flex min-h-16 items-center gap-4 rounded-2xl border border-line bg-paper px-4 py-3 transition-colors hover:border-brand",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "grid h-12 w-12 shrink-0 place-items-center rounded-full bg-lilac text-brand",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-5 w-5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block text-sm text-muted",
													children: "E-mail"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block break-all text-base font-medium text-ink sm:text-lg",
													children: EMAIL
												})]
											})]
										})]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: openChat,
								className: "rounded-3xl bg-mist p-6 ring-1 ring-line lg:col-span-6 lg:p-8",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-3xl text-ink",
										children: "Começar uma conversa"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted",
										children: "O recado abre no WhatsApp da Jeniffer, pronto para enviar."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
										className: "mt-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
											className: "text-sm font-medium text-ink",
											children: "Sobre o que você quer falar?"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3 flex flex-wrap gap-2",
											children: services.map((service) => {
												const selected = service.id === serviceId;
												return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													"aria-pressed": selected,
													onClick: () => setServiceId(service.id),
													className: `min-h-11 rounded-full border px-4 py-2 text-left text-sm transition-colors ${selected ? "border-brand bg-brand text-paper" : "border-line bg-paper text-ink hover:border-brand"}`,
													children: service.title
												}, service.id);
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										htmlFor: "recado",
										className: "mt-6 block text-sm font-medium text-ink",
										children: ["Recado ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-normal text-muted",
											children: "(opcional)"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										id: "recado",
										name: "recado",
										rows: 4,
										maxLength: 400,
										value: note,
										onChange: (event) => setNote(event.target.value),
										placeholder: "Conte em uma frase o que você precisa.",
										className: "mt-2 w-full resize-none rounded-2xl border border-line bg-paper px-4 py-3 text-base text-ink outline-none placeholder:text-muted focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "submit",
										className: "mt-5 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-brand px-6 text-base font-medium text-paper transition-transform duration-150 ease-out hover:bg-brand-deep active:scale-[0.96] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, { className: "h-5 w-5" }), "Abrir conversa no WhatsApp"]
									})
								]
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "bg-brand-deep px-5 pb-28 pt-10 text-paper md:pb-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-6 sm:flex-row sm:items-end sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "h-9 w-9 text-paper" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-display text-lg leading-none",
							children: "JL serviços"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-display text-sm italic text-paper/80",
							children: "terceirizados"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-paper/75",
						children: "Seu negócio em boas mãos."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm text-paper/75",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: helloHref,
								target: "_blank",
								rel: "noopener noreferrer",
								className: "block hover:text-paper",
								children: WHATSAPP_DISPLAY
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `mailto:${EMAIL}`,
								className: "mt-1 block break-all hover:text-paper",
								children: EMAIL
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4",
								children: [
									"© ",
									(/* @__PURE__ */ new Date()).getFullYear(),
									" JL Serviços Terceirizados"
								]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-40 border-t border-line bg-paper/95 p-3 backdrop-blur-md md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: helloHref,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "flex h-12 items-center justify-center gap-2 rounded-full bg-brand text-sm font-medium text-paper",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, { className: "h-4 w-4" }), "Falar com a Jeniffer no WhatsApp"]
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LandingPage, {});
}
//#endregion
export { Home as component };
